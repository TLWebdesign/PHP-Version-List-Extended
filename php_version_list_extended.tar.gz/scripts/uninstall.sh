#!/bin/sh

echo "Plugin Un-Installed!"

exit 0